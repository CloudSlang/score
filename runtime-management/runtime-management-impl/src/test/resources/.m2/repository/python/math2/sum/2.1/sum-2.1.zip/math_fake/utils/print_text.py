import sys

def foo(var):
	return var + '+' + var
